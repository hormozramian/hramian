---
hide:
  - title
  #- footer
---


## Functions


!!! info "Calling Variables and Environment Objects"
    Defining variables within the software environment or alternatively importing data from external resources amounts to variables to become available under the workspace for immediate use. 