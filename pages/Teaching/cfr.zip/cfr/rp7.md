---
hide:
  - title
  #- footer
  #- toc
---

## Loops