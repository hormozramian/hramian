---
hide:
  - title
  #- footer
  #- toc
---

## System Commands

[system](https://stat.ethz.ch/R-manual/R-devel/library/base/html/system.html)