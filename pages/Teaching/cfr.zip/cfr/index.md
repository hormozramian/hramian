---
hide:
  - title
  - footer
---

The goals of this course is to demonstrates the applications of software computations to  

Financial and economic decisions are determined by wide-ranging drivers. Human behaviour, preferences for consumption and investment products, supply-side fundamentals, policy and regulatory responses and many other factors determine the world of finance and economics. 

Such drivers are often times explicitly recorded in data or  indirectly captured by alternative means that are transformable to quantitative or numeric metrics. The availability and growth of data requires appropriate computational platforms to process and organise information in its unstructured form to *actionable* and *interpretable* forms.


## Course Outline



- Basics
- Data Processing
- Statistical Analysis
- Numerical and Computational Tools
- Applications

## Prerequisites
There is no formal prerequisite, however a prior background including calculus, statistics and regression  is favourable. The course assumes familiarity with the estimation and inference of the least squares framework covered earlier in the semester one courses.

## Datasets

- Financial Analysis
- Health Economics


## Code Files

- Practice Code 1
- Practice Code 2

## Reading
The course primarily relies on the *first* reference below:

1. *Garrett Wickham, Garrett Grolemund*, 2017, **R for Data Science: Import, Tidy, Transform, Visualize, and Model Data**,  ISBN-13: 978-1491910399
2. *John Braun*, 2021, **A First Course in Statistical Programming with R**, ISBN-13: 978-1108995146
3. *Christensen, T.M., Hurn, A.S. and Lindsay, K.A.*, 2008. **The devil is in the detail: hints for practical optimisation**. Economic Analysis and Policy, 38(2), pp.345-368. 
4. *Ken Kelley, Keke Lai and Po-Ju Wu*, 2008,Best Practices in Quantiative Methods, **Chapter 34 [Using R for Data Analysis: A Best Practice for Research](/../assets/Kelley_Lai_Wu_Using_R_2008.pdf)**,

Further research-level readings are provided by **[The R Journal](https://journal.r-project.org)** presenting peer-reviewed and open-access material complied on the computational operations and applications of the software to specialised purposes.